<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Models\Package as ModelsPackage;
use Illuminate\Http\Request;
use App\Models\Package;

// class PController extends Controller
// {
//     public function getPackage(){
//         return response()->json(Package::all());
//     }
// }
