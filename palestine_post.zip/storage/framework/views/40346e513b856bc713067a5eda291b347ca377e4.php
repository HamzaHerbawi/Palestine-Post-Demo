<div class="form-group">
	<?php
		$fieldset = [
			'text' => !isset($row->details->fieldset) ? $row->display_name : $row->details->fieldset->text ?? $row->display_name,
			'align' => !isset($row->details->fieldset) ? 'left' : $row->details->fieldset->align ?? 'left',
			'bgcolor' => !isset($row->details->fieldset) ? '#ffffff' : $row->details->fieldset->bgcolor ?? '#ffffff'
		];
	?>
	
	<fieldset>	
		<legend class="text-<?php echo e($fieldset['align']); ?>" style="background-color: <?php echo e($fieldset['bgcolor']); ?>;padding: 5px;"><?php echo e($fieldset['text']); ?></legend>
	<?php if( !isset($dataTypeContent->id) ): ?>
		<?php echo $__env->make('voyager::formfields.select_dependent_dropdown.partials.add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>	
	<?php else: ?>
		<?php echo $__env->make('voyager::formfields.select_dependent_dropdown.partials.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	</fieldset>
	
</div>


<?php $__env->startPush('javascript'); ?>
<script src="<?php echo e(url('js/dependent-dropdown.js')); ?>"></script>
<script>
	var x = document.getElementsByTagName("label");
	for (var i=0; i<x.length; i++) {	
		if ( x[i].textContent === "<?php echo e($row->display_name); ?>" ) {
			x[i].style.display = 'none';
			break;
		}		
	}
</script>
<?php $__env->stopPush(); ?><?php /**PATH /home/hamza/www/palestine_post_/vendor/tcg/voyager/src/../resources/views/formfields/select_dependent_dropdown/select_dependent_dropdown.blade.php ENDPATH**/ ?>