<?php $__env->startSection('page_title', __('voyager::generic.view').' '.$dataType->getTranslatedAttribute('display_name_singular')); ?>

<?php $__env->startSection('page_header'); ?>
<style>

    body{
background:#eee;
margin-top:20px;
}
.text-danger strong {
        	color: #9f181c;
		}
		.receipt-main {
			background: #ffffff none repeat scroll 0 0;
			border-bottom: 12px solid #080808;
			border-top: 12px solid #c53438;
			margin-top: 50px;
			margin-bottom: 50px;
			padding: 40px 30px !important;
			position: relative;
			box-shadow: 0 1px 21px #acacac;
			color: #333333;
			font-family: open sans;
		}
		.receipt-main p {
			color: #333333;
			font-family: open sans;
			line-height: 1.42857;
		}
		.receipt-footer h1 {
			font-size: 15px;
			font-weight: 400 !important;
			margin: 0 !important;
		}
		.receipt-main::after {
			background: #414143 none repeat scroll 0 0;
			content: "";
			height: 5px;
			left: 0;
			position: absolute;
			right: 0;
			top: -13px;
		}
		.receipt-main thead {
			background: #414143 none repeat scroll 0 0;
		}
		.receipt-main thead th {
			color:#fff;
		}
		.receipt-right h5 {
			font-size: 16px;
			font-weight: bold;
			margin: 0 0 7px 0;
		}
		.receipt-right p {
			font-size: 12px;
			margin: 0px;
		}
		.receipt-right p i {
			text-align: center;
			width: 18px;
		}
		.receipt-main td {
			padding: 9px 20px !important;
		}
		.receipt-main th {
			padding: 13px 20px !important;
		}
		.receipt-main td {
			font-size: 13px;
			font-weight: initial !important;
		}
		.receipt-main td p:last-child {
			margin: 0;
			padding: 0;
		}
		.receipt-main td h2 {
			font-size: 20px;
			font-weight: 900;
			margin: 0;
			text-transform: uppercase;
		}
		.receipt-header-mid .receipt-left h1 {
			font-weight: 100;
			margin: 34px 0 0;
			text-align: right;
			text-transform: uppercase;
		}
		.receipt-header-mid {
			margin: 24px 0;
			overflow: hidden;
		}

		#container {
			background-color: #dcdcdc;
		}
</style>
<h1 class="page-title">

    <i class="<?php echo e($dataType->icon); ?>"></i> <?php echo e(__('Invoice')); ?> <?php echo e(ucfirst($dataType->getTranslatedAttribute('printing'))); ?> &nbsp;

    <div class="btn btn-primary ks-light ks-print print">
        <i class="voyager-polaroid"></i>
        
        <span class="la la-print"></span>
        <span class="ks-text">Print Invoice</span>
      </div>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $dataTypeContent)): ?>
        <a href="<?php echo e(route('voyager.'.$dataType->slug.'.edit', $dataTypeContent->getKey())); ?>" class="btn btn-info">
            <i class="glyphicon glyphicon-pencil"></i> <span class="hidden-xs hidden-sm"><?php echo e(__('voyager::generic.edit')); ?></span>
        </a>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete', $dataTypeContent)): ?>
        <?php if($isSoftDeleted): ?>
            <a href="<?php echo e(route('voyager.'.$dataType->slug.'.restore', $dataTypeContent->getKey())); ?>" title="<?php echo e(__('voyager::generic.restore')); ?>" class="btn btn-default restore" data-id="<?php echo e($dataTypeContent->getKey()); ?>" id="restore-<?php echo e($dataTypeContent->getKey()); ?>">
                <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm"><?php echo e(__('voyager::generic.restore')); ?></span>
            </a>
        <?php else: ?>
            <a href="javascript:;" title="<?php echo e(__('voyager::generic.delete')); ?>" class="btn btn-danger delete" data-id="<?php echo e($dataTypeContent->getKey()); ?>" id="delete-<?php echo e($dataTypeContent->getKey()); ?>">
                <i class="voyager-trash"></i> <span class="hidden-xs hidden-sm"><?php echo e(__('voyager::generic.delete')); ?></span>
            </a>
        <?php endif; ?>
    <?php endif; ?>
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('browse', $dataTypeContent)): ?>
    <a href="<?php echo e(route('voyager.'.$dataType->slug.'.index')); ?>" class="btn btn-warning">
        <i class="glyphicon glyphicon-list"></i> <span class="hidden-xs hidden-sm"><?php echo e(__('voyager::generic.return_to_list')); ?></span>
    </a>
    <?php endif; ?>
</h1>
<?php echo $__env->make('voyager::multilingual.language-selector', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-md-12" id="div_print">
    <style>
        .div1{
            float: right;
        }
        .button{
            color: darkgoldenrod;
        }
        .flex-parent {
            display: flex;
        }

        .jc-center {
            justify-content: center;
        }

        button.margin-right {
            margin-right: 20px;
        }
                    </style>

    <div class="row">
           <div class="receipt-main col-xs-10 col-sm-10 col-md-6 col-xs-offset-1 col-sm-offset-1 col-md-offset-3">
               <div class="row">
                   <div class="receipt-header">
                       <div class="col-xs-6 col-sm-6 col-md-6">
                       </div>
                       <div class="col-xs-6 col-sm-6 col-md-6 text-right">
                           <div class="div1">
                               <h4>Palestine Post / البريد الفلسطيني </h4>
                               <p>info@palpost.ps<i class="fa fa-envelope-o"></i></p>
                               <p>Palestine <i class="fa fa-location-arrow"></i></p>
                           </div>
                           <br>
                           <br>
                           <br>
                           <br>
                           <br>
                       </div>
                   </div>
               </div>

               <div class="row">
                   <div class="receipt-header receipt-header-mid">
                       <div class="col-xs-8 col-sm-8 col-md-8 text-left">
                           <div class="receipt-right">
                            <p><b>Clinet Name :</b> ________</p>
                            <p><b> Phone :</b> ___________</p>
                            <p><b>Address :</b> ___________ </p>
                           </div>
                       </div>
                       <div class="col-xs-4 col-sm-4 col-md-4">
                       </div>
                   </div>
                   <br>
               </div>
               <div>
<div class="page-content read container-fluid">
    <div class="row">
        <div class="col-md-12">

            <div class="panel panel-bordered" style="padding-bottom:5px;">
                <!-- form start -->
                <?php $__currentLoopData = $dataType->readRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php
                    if ($dataTypeContent->{$row->field.'_read'}) {
                        $dataTypeContent->{$row->field} = $dataTypeContent->{$row->field.'_read'};
                    }
                    ?>

                    <div class="panel-heading" style="border-bottom:0;">
                        <h3 class="panel-title"><?php echo e($row->getTranslatedAttribute('display_name')); ?></h3>
                    </div>

                    <div class="panel-body" style="padding-top:0;">
                        <?php if(isset($row->details->view_read)): ?>
                            <?php echo $__env->make($row->details->view_read, ['row' => $row, 'dataType' => $dataType, 'dataTypeContent' => $dataTypeContent, 'content' => $dataTypeContent->{$row->field}, 'view' => 'read', 'options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif(isset($row->details->view)): ?>
                            <?php echo $__env->make($row->details->view, ['row' => $row, 'dataType' => $dataType, 'dataTypeContent' => $dataTypeContent, 'content' => $dataTypeContent->{$row->field}, 'action' => 'read', 'view' => 'read', 'options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($row->type == "image"): ?>
                            <img class="img-responsive"
                                 src="<?php echo e(filter_var($dataTypeContent->{$row->field}, FILTER_VALIDATE_URL) ? $dataTypeContent->{$row->field} : Voyager::image($dataTypeContent->{$row->field})); ?>">
                        <?php elseif($row->type == 'multiple_images'): ?>
                            <?php if(json_decode($dataTypeContent->{$row->field})): ?>
                                <?php $__currentLoopData = json_decode($dataTypeContent->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <img class="img-responsive"
                                         src="<?php echo e(filter_var($file, FILTER_VALIDATE_URL) ? $file : Voyager::image($file)); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php else: ?>
                                <img class="img-responsive"
                                     src="<?php echo e(filter_var($dataTypeContent->{$row->field}, FILTER_VALIDATE_URL) ? $dataTypeContent->{$row->field} : Voyager::image($dataTypeContent->{$row->field})); ?>">
                            <?php endif; ?>
                        <?php elseif($row->type == 'relationship'): ?>
                             <?php echo $__env->make('voyager::formfields.relationship', ['view' => 'read', 'options' => $row->details], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($row->type == 'select_dropdown' && property_exists($row->details, 'options') &&
                                !empty($row->details->options->{$dataTypeContent->{$row->field}})
                        ): ?>
                            <?php echo $row->details->options->{$dataTypeContent->{$row->field}};?>
                        <?php elseif($row->type == 'select_multiple'): ?>
                            <?php if(property_exists($row->details, 'relationship')): ?>

                                <?php $__currentLoopData = json_decode($dataTypeContent->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php echo e($item->{$row->field}); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <?php elseif(property_exists($row->details, 'options')): ?>
                                <?php if(!empty(json_decode($dataTypeContent->{$row->field}))): ?>
                                    <?php $__currentLoopData = json_decode($dataTypeContent->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(@$row->details->options->{$item}): ?>
                                            <?php echo e($row->details->options->{$item} . (!$loop->last ? ', ' : '')); ?>

                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <?php echo e(__('voyager::generic.none')); ?>

                                <?php endif; ?>
                            <?php endif; ?>
                        <?php elseif($row->type == 'date' || $row->type == 'timestamp'): ?>
                            <?php if( property_exists($row->details, 'format') && !is_null($dataTypeContent->{$row->field}) ): ?>
                                <?php echo e(\Carbon\Carbon::parse($dataTypeContent->{$row->field})->formatLocalized($row->details->format)); ?>

                            <?php else: ?>
                                <?php echo e($dataTypeContent->{$row->field}); ?>

                            <?php endif; ?>
                        <?php elseif($row->type == 'checkbox'): ?>
                            <?php if(property_exists($row->details, 'on') && property_exists($row->details, 'off')): ?>
                                <?php if($dataTypeContent->{$row->field}): ?>
                                <span class="label label-info"><?php echo e($row->details->on); ?></span>
                                <?php else: ?>
                                <span class="label label-primary"><?php echo e($row->details->off); ?></span>
                                <?php endif; ?>
                            <?php else: ?>
                            <?php echo e($dataTypeContent->{$row->field}); ?>

                            <?php endif; ?>
                        <?php elseif($row->type == 'color'): ?>
                            <span class="badge badge-lg" style="background-color: <?php echo e($dataTypeContent->{$row->field}); ?>"><?php echo e($dataTypeContent->{$row->field}); ?></span>
                        <?php elseif($row->type == 'coordinates'): ?>
                            <?php echo $__env->make('voyager::partials.coordinates', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                        <?php elseif($row->type == 'rich_text_box'): ?>
                            <?php echo $__env->make('voyager::multilingual.input-hidden-bread-read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $dataTypeContent->{$row->field}; ?>

                        <?php elseif($row->type == 'file'): ?>
                            <?php if(json_decode($dataTypeContent->{$row->field})): ?>
                                <?php $__currentLoopData = json_decode($dataTypeContent->{$row->field}); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($file->download_link) ?: ''); ?>">
                                        <?php echo e($file->original_name ?: ''); ?>

                                    </a>
                                    <br/>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php elseif($dataTypeContent->{$row->field}): ?>
                                <a href="<?php echo e(Storage::disk(config('voyager.storage.disk'))->url($row->field) ?: ''); ?>">
                                    <?php echo e(__('voyager::generic.download')); ?>

                                </a>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php echo $__env->make('voyager::multilingual.input-hidden-bread-read', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <p><?php echo e($dataTypeContent->{$row->field}); ?></p>
                        <?php endif; ?>
                    </div><!-- panel-body -->
                    <?php if(!$loop->last): ?>
                        <hr style="margin:0;">
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
        </div>
    </div>
    <p><b>Employee's signature :</b> ________</p>
    <p><b>Client's signature :</b> ___________ </p>
</div>



            
        </div><!-- /.modal-content -->
    </div><!-- /.modal-dialog -->
</div><!-- /.modal -->
<?php $__env->stopSection(); ?>
<?php $__env->startSection('javascript'); ?>
<script type="text/javascript">
    $(function () {
           $(".print").on('click', function () {

               var w = window.open('Print');
               w.document.write($('#div_print').html());
               w.print();
               w.close();
           });
       });
</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('voyager::master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/hamza/Documents/Post_/vendor/tcg/voyager/src/../resources/views/invoices/read.blade.php ENDPATH**/ ?>