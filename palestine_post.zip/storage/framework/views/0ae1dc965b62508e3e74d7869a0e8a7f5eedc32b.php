	
	<?php 
		$model = class_exists($row->details->model) ? app($row->details->model) : null;
		
		$errors = [];
		if (!class_exists($row->details->model)) $errors[] = $row->details->model;						// check error
		
		$selects = $row->details->dependent_dropdown;
		foreach ($selects as $class) { if (!class_exists($class->model)) $errors[] = $class->model; }	// check error
		
		$count = count($selects)+1;
		$css = ( $count == 2 ? 'col-md-6' : ( $count == 3 ? 'col-md-4' : 'col-md-3') );
	?>
	
	<?php if(!count($errors)): ?>	
		<?php $query = $model::pluck($row->details->label, $row->details->key); ?>
		<!-- // add first select -->
		<div class="<?php echo e($css); ?>" style="padding: 10px;">
			<label for="<?php echo e($row->details->name); ?>"><?php echo e($row->details->display); ?></label>
			<select id="<?php echo e($row->details->name); ?>" name="<?php echo e($row->details->name); ?>" class="form-group select2 dependent-dropdown"
					data-route="<?php echo e(route($row->details->route)); ?>"
					data-params="<?php echo e(json_encode(['options' => $selects[0], 'model' => $selects[0]->model, 'where' => $selects[0]->where, 'value' => '__value'])); ?>"
					<?php if(isset($row->details->placeholder)): ?><?php echo e('placeholder="$row->details->placeholder"'); ?><?php endif; ?>>
				<?php if(isset($row->details->placeholder)): ?>
                    <option value="0" selected="selected"><?php echo e($row->details->placeholder); ?></option>
                <?php endif; ?>	
				<!-- options -->
				<?php $__currentLoopData = $query; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<option value="<?php echo e($key); ?>"><?php echo e($value); ?></option>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</select>
		</div>
		
		<!-- // add second/three select -->
		<?php $__currentLoopData = $selects; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $next = ++$key; ?>
			<div class="<?php echo e($css); ?>" style="padding: 10px;">
			<?php if(isset($selects[$next])): ?>
				<label for="<?php echo e($item->name); ?>"><?php echo e($item->display); ?></label>
				<select id="<?php echo e($item->name); ?>" name="<?php echo e($item->name); ?>" class="form-group select2 dependent-dropdown"
						data-route="<?php echo e(route($row->details->route)); ?>"
						data-params="<?php echo e(json_encode(['options' => $selects[$next], 'model' => $selects[$next]->model, 'where' => $selects[$next]->where, 'value' => '__value'])); ?>"
						placeholder="<?php echo e($item->placeholder); ?>">
					<?php if(isset($item->placeholder)): ?>
					<option value="0" selected="selected"><?php echo e($item->placeholder); ?></option>
					<?php endif; ?>
				</select>
			<?php else: ?>
				<label for="<?php echo e($item->name); ?>"><?php echo e($item->display); ?></label>
				<select id="<?php echo e($item->name); ?>" name="<?php echo e($item->name); ?>" class="form-group select2" placeholder="<?php echo e($item->placeholder); ?>">
					<?php if(isset($item->placeholder)): ?>
					<option value="0" selected="selected"><?php echo e($item->placeholder); ?></option>
					<?php endif; ?>
				</select>
			<?php endif; ?>
			</div>		
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php else: ?>
		<?php $__currentLoopData = $errors; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<span class="help-block danger">cannot make relationship because <?php echo e($model); ?> does not exist.</span>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	<?php endif; ?><?php /**PATH /home/hamza/www/palestine_post_/vendor/tcg/voyager/src/../resources/views/formfields/select_dependent_dropdown/partials/add.blade.php ENDPATH**/ ?>